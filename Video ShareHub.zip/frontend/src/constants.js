export const BASE_URL = import.meta.env.VITE_BACKEND_URL || import.meta.env.BACKEND_URL;
